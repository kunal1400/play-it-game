<div class="wrap">
	<h1>How to Setup a Game</h1>
	<ol>
		<li>From the Game Page Settings, uncheck "Is Team Game?" checkbox</li>		
	</ol>
</div>