<?php
namespace Elementor;

class Elementor_playit_loginbycode_Widget extends Widget_Base {
	public function __construct($data = [], $args = null) {
		parent::__construct($data, $args);
		// wp_register_script( 'playit-scripts', '/js/script.js', [ 'elementor-frontend' ], '1.0.0', true );
		// wp_register_style( 'playit-styles', '/css/style.css');
	}

	// public function get_script_depends() {
	// 	return [ 'playit-scripts' ];
	// }

	// public function get_style_depends() {
	// 	return [ 'playit-styles' ];
	// }

	public function get_name() {
		return 'playit-login-by-code';
	}

	public function get_title() {
		return __( 'Playit Login By Code', 'plugin-name' );
	}

	public function get_icon() {
		return 'eicon-lock-user';
	}

	public function get_categories() {
		return [ 'general' ];
	}

	protected function _register_controls() {
		/**
		* Hours Section
		**/
		$this->start_controls_section(
			'login_by_code',
			[
				'label' => __( 'Login By Code', 'plugin-name' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);		
		
		$this->settings();

		$this->end_controls_section();
		/*** END Content Section ***/		
	}

	protected function render() {
		$attributes = $this->get_settings_for_display();		
		
		// echo '<pre>';
		// print_r($attributes);
		// echo '</pre>';

		echo '<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#join_game_by_code_modal" style="background-color:'.$attributes['login_button_background_color'].';border: 1px solid '.$attributes['login_button_background_color'].';font-family:'.$attributes['login_button_font_family'].'"
		>'.$attributes['login_button_label'].'</button>
		<div class="modal fade" id="join_game_by_code_modal" tabindex="-1" role="dialog" aria-labelledby="join_game_by_code_modal_label" aria-hidden="true">
		  <div class="modal-dialog modal-dialog-centered" role="document">
		    <div class="modal-content">
		      <div class="modal-header">
		        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title" id="myModalLabel">'.$attributes['modal_title'].'</h4>
		      </div>
				<form onsubmit="return applyCodeForGame()" method="post" id="codeLoginForm">
		      		<div class="modal-body">
			        	<div class="md-form mb-5">
							<label for="form34">User Name</label>
							<input type="text" id="form34" name="user_name" class="form-control" value="">
				        </div>
				        <div style="display:none" class="md-form mb-5">
							<label for="form35">Code</label>
							<input type="text" id="form35" name="user_code" class="form-control" value="">
				        </div>
			      	</div>
		      		<div class="modal-footer">
		      			<input type="hidden" name="game_id" value="'.$attributes['login_button_game_id'].'" />
		      			<input type="hidden" name="redirect_url" value="'.$attributes['redirect_url']['url'].'" />
		        		<button type="button" class="btn btn-secondary" data-dismiss="modal">'.$attributes['close_button_label'].'</button>
		        		<button type="submit" class="btn btn-primary">'.$attributes['submit_button_label'].'</button>
		      		</div>
		    	</form>
		    </div>
		  </div>
		</div>';

	}

	public function settings() {
		$this->add_control(
			'login_button_background_color',
			[
				'label' => __( 'Login Background Color', 'plugin-name' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '#23a455',
			]
		);

		$this->add_control(
			'login_button_font_family',
			[
				'label' => __( 'Login Font Family', 'plugin-domain' ),
				'type' => \Elementor\Controls_Manager::FONT,
				'default' => "'Open Sans', sans-serif",
				'selectors' => [
					'{{WRAPPER}} .title' => 'font-family: {{VALUE}}',
				]
			]
		);

		$this->add_control(
			'login_button_text_color',
			[
				'label' => __( 'Login Text Color', 'plugin-name' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '#fefefe',
			]
		);

		$this->add_control(
			'login_button_game_id',
			[
				'label' => __( 'Game Id', 'plugin-name' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'input_type' => 'text',
				'placeholder' => __( 'Enter Game Id', 'plugin-name' ),
				'default' => ''
			]
		);

		$this->add_control(
			'login_button_label',
			[
				'label' => __( 'Login Button Label', 'plugin-name' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'input_type' => 'text',
				'placeholder' => __( 'Login Button Label', 'plugin-name' ),
				'default' => "Login"
			]
		);

		$this->add_control(
			'logout_button_label',
			[
				'label' => __( 'Logout Button Label', 'plugin-name' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'input_type' => 'text',
				'placeholder' => __( 'Logout', 'plugin-name' ),
				'default' => 'Logout'
			]
		);

		$this->add_control(
			'submit_button_label',
			[
				'label' => __( 'Submit Button Label', 'plugin-name' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'input_type' => 'text',
				'placeholder' => __( 'Submit', 'plugin-name' ),
				'default' => 'Submit'
			]
		);

		$this->add_control(
			'close_button_label',
			[
				'label' => __( 'Close Button Label', 'plugin-name' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'input_type' => 'text',
				'placeholder' => __( 'Close', 'plugin-name' ),
				'default' => "Close"
			]
		);

		$this->add_control(
			'modal_title',
			[
				'label' => __( 'Modal Title', 'plugin-name' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'input_type' => 'text',
				'placeholder' => __( 'Join Team By Code', 'plugin-name' ),
				'default' => "Join Team By Code"
			]
		);

		$this->add_control(
			'redirect_url',
			[
				'label' => __( 'Redirect URL', 'plugin-name' ),
				'type' => \Elementor\Controls_Manager::URL,				
				'default' => [
					'url' => site_url(),
				],
				'options' => false,
			]
		);	
	}

	// public function getStyle( $str, $arr ) {		
	// 	$ret = "";
	// 	$ret .= $str.'-top:'.$arr['top'].$arr['unit'].';';
	// 	$ret .= $str.'-right:'.$arr['right'].$arr['unit'].';';
	// 	$ret .= $str.'-bottom:'.$arr['bottom'].$arr['unit'].';';
	// 	$ret .= $str.'-left:'.$arr['left'].$arr['unit'].';';

	// 	return $ret;
	// }

}