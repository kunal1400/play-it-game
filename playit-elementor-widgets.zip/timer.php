<?php
namespace Elementor;

class Elementor_playit_Widget extends Widget_Base {
	public function __construct($data = [], $args = null) {
		parent::__construct($data, $args);
		wp_register_script( 'playit-scripts', '/js/script.js', [ 'elementor-frontend' ], '1.0.0', true );
		wp_register_style( 'playit-styles', '/css/style.css');
	}

	public function get_script_depends() {
		return [ 'playit-scripts' ];
	}

	public function get_style_depends() {
		return [ 'playit-styles' ];
	}

	public function get_name() {
		return 'playit-timer';
	}

	public function get_title() {
		return __( 'Playit Timer', 'plugin-name' );
	}

	public function get_icon() {
		return 'eicon-countdown';
	}

	public function get_categories() {
		return [ 'general' ];
	}

	protected function _register_controls() {
		/**
		* Hours Section
		**/
		$this->start_controls_section(
			'hours_section',
			[
				'label' => __( 'Hours', 'plugin-name' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);		
		
		$this->settings('Hours ');

		$this->end_controls_section();
		/*** END Content Section ***/

		/**
		* Hours Section
		**/
		$this->start_controls_section(
			'minutes_section',
			[
				'label' => __( 'Minutes', 'plugin-name' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);		
		
		$this->settings('Minutes ');

		$this->end_controls_section();
		/*** END Content Section ***/

		/**
		* Hours Section
		**/
		$this->start_controls_section(
			'seconds_section',
			[
				'label' => __( 'Seconds', 'plugin-name' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);		
		
		$this->settings('Seconds ');

		$this->end_controls_section();
		/*** END Content Section ***/		
	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		$timerWrapper = "timerwrapper_".rand(10,10000);

		// echo "<pre>";
		// print_r($settings);
		// echo "</pre>";
		?>
		<style type="text/css">
			.<?php echo $timerWrapper ?> .hourBox {
				<?php echo $this->getStyle( 'padding', $settings['hours_box_padding'] ) ?>
				<?php echo $this->getStyle( 'margin', $settings['hours_box_margin'] ) ?>
			}			
			.<?php echo $timerWrapper ?> .minuteBox {
				<?php echo $this->getStyle( 'padding', $settings['minutes_box_padding'] ) ?>
				<?php echo $this->getStyle( 'margin', $settings['minutes_box_margin'] ) ?>
			}			
			.<?php echo $timerWrapper ?> .secondBox {
				<?php echo $this->getStyle( 'padding', $settings['seconds_box_padding'] ) ?>
				<?php echo $this->getStyle( 'margin', $settings['seconds_box_margin'] ) ?>
			}			

			.<?php echo $timerWrapper ?> .hourBox h1 {
				<?php echo $this->getStyle( 'margin', $settings['hours_margin'] ) ?>
				font-family: <?php echo $settings['hours_font_family'] ?>;
				color: <?php echo $settings['hours_text_color'] ?>;
				font-size: <?php echo $settings['hours_font_size']['size'].$settings['hours_font_size']['unit'] ?>;
			}
			.<?php echo $timerWrapper ?> .minuteBox h1 {
				<?php echo $this->getStyle( 'margin', $settings['minutes_margin'] ) ?>
				font-family: <?php echo $settings['minutes_font_family'] ?>;
				color: <?php echo $settings['hours_text_color'] ?>;
				font-size: <?php echo $settings['minutes_font_size']['size'].$settings['minutes_font_size']['unit'] ?>;
			}
			.<?php echo $timerWrapper ?> .secondBox h1 {
				<?php echo $this->getStyle( 'margin', $settings['seconds_margin'] ) ?>
				font-family: <?php echo $settings['seconds_font_family'] ?>;
				color: <?php echo $settings['hours_text_color'] ?>;
				font-size: <?php echo $settings['seconds_font_size']['size'].$settings['seconds_font_size']['unit'] ?>;
			}

			.<?php echo $timerWrapper ?> .hourBox p {
				font-family: <?php echo $settings['hours_label_font_family'] ?>;
				font-size: <?php echo $settings['hours_label_font_size']['size'].$settings['hours_label_font_size']['unit'] ?>;
				color: <?php echo $settings['hours_label_text_color'] ?>;
			}
			.<?php echo $timerWrapper ?> .minuteBox p {
				font-family: <?php echo $settings['minutes_label_font_family'] ?>;
				font-size: <?php echo $settings['minutes_label_font_size']['size'].$settings['minutes_label_font_size']['unit'] ?>;
				color: <?php echo $settings['minutes_label_text_color'] ?>;
			}
			.<?php echo $timerWrapper ?> .secondBox p {
				font-family: <?php echo $settings['seconds_label_font_family'] ?>;
				font-size: <?php echo $settings['seconds_label_font_size']['size'].$settings['seconds_label_font_size']['unit'] ?>;
				color: <?php echo $settings['seconds_label_text_color'] ?>;
			}

			.<?php echo $timerWrapper ?> .hourBackgroundColor {
				background-color: <?php echo $settings['hours_box_background_color'] ?>;
			}
			.<?php echo $timerWrapper ?> .minuteBackgroundColor {
				background-color: <?php echo $settings['minutes_box_background_color'] ?>;
			}
			.<?php echo $timerWrapper ?> .secondBackgroundColor{
				background-color: <?php echo $settings['seconds_box_background_color'] ?>;
			}

			/* Extra small devices (phones, 600px and down) */
			@media only screen and (max-width: 600px) {
				.<?php echo $timerWrapper ?> .hourBox {
					<?php echo $this->getStyle( 'padding', $settings['hours_box_padding_mobile'] ) ?>
					<?php echo $this->getStyle( 'margin', $settings['hours_box_margin_mobile'] ) ?>
				}
				.<?php echo $timerWrapper ?> .minuteBox {
					<?php echo $this->getStyle( 'padding', $settings['minutes_box_padding_mobile'] ) ?>
					<?php echo $this->getStyle( 'margin', $settings['minutes_box_margin_mobile'] ) ?>
				}
				.<?php echo $timerWrapper ?> .secondBox {
					<?php echo $this->getStyle( 'padding', $settings['seconds_box_padding_mobile'] ) ?>
					<?php echo $this->getStyle( 'margin', $settings['seconds_box_margin_mobile'] ) ?>
				}
				.<?php echo $timerWrapper ?> .hourBox h1 {
					<?php echo $this->getStyle( 'margin', $settings['hours_margin_mobile'] ) ?>
					font-size: <?php echo $settings['hours_font_size_mobile']['size'].$settings['hours_font_size_mobile']['unit'] ?>;					
				}
				.<?php echo $timerWrapper ?> .minuteBox h1 {
					<?php echo $this->getStyle( 'margin', $settings['minutes_margin_mobile'] ) ?>
					font-size: <?php echo $settings['minutes_font_size_mobile']['size'].$settings['minutes_font_size_mobile']['unit'] ?>;					
				}
				.<?php echo $timerWrapper ?> .secondBox h1 {
					<?php echo $this->getStyle( 'margin', $settings['seconds_margin_mobile'] ) ?>
					font-size: <?php echo $settings['seconds_font_size_mobile']['size'].$settings['seconds_font_size']['unit'] ?>;					
				}

				.<?php echo $timerWrapper ?> .hourBox p {
					font-size: <?php echo $settings['hours_label_font_size_mobile']['size'].$settings['hours_label_font_size_mobile']['unit'] ?>;
				}
				.<?php echo $timerWrapper ?> .minuteBox p {
					font-size: <?php echo $settings['minutes_label_font_size_mobile']['size'].$settings['minutes_label_font_size_mobile']['unit'] ?>;
				}
				.<?php echo $timerWrapper ?> .secondBox p {
					font-size: <?php echo $settings['seconds_label_font_size_mobile']['size'].$settings['seconds_label_font_size_mobile']['unit'] ?>;
				}

			/* Small devices (portrait tablets and large phones, 600px and up) */
			@media only screen and (min-width: 600px) {
				.<?php echo $timerWrapper ?> .hourBox {
					<?php echo $this->getStyle( 'padding', $settings['hours_box_padding_tablet'] ) ?>
					<?php echo $this->getStyle( 'margin', $settings['hours_box_margin_tablet'] ) ?>
				}
				.<?php echo $timerWrapper ?> .minuteBox {
					<?php echo $this->getStyle( 'padding', $settings['minutes_box_padding_tablet'] ) ?>
					<?php echo $this->getStyle( 'margin', $settings['minutes_box_margin_tablet'] ) ?>
				}
				.<?php echo $timerWrapper ?> .secondBox {
					<?php echo $this->getStyle( 'padding', $settings['seconds_box_padding_tablet'] ) ?>
					<?php echo $this->getStyle( 'margin', $settings['seconds_box_margin_tablet'] ) ?>
				}

				.<?php echo $timerWrapper ?> .hourBox h1 {
					<?php echo $this->getStyle( 'margin', $settings['hours_margin_tablet'] ) ?>
					font-size: <?php echo $settings['hours_font_size_tablet']['size'].$settings['hours_font_size_tablet']['unit'] ?>;
				}
				.<?php echo $timerWrapper ?> .minuteBox h1 {
					<?php echo $this->getStyle( 'margin', $settings['minutes_margin_tablet'] ) ?>
					font-size: <?php echo $settings['minutes_font_size_tablet']['size'].$settings['minutes_font_size_tablet']['unit'] ?>;
				}
				.<?php echo $timerWrapper ?> .secondBox h1 {
					<?php echo $this->getStyle( 'margin', $settings['seconds_margin_tablet'] ) ?>
					font-size: <?php echo $settings['seconds_font_size_tablet']['size'].$settings['seconds_font_size_tablet']['unit'] ?>;
				}

				.<?php echo $timerWrapper ?> .hourBox p {
					font-size: <?php echo $settings['hours_label_font_size_tablet']['size'].$settings['hours_label_font_size_tablet']['unit'] ?>;
				}
				.<?php echo $timerWrapper ?> .minuteBox p {
					font-size: <?php echo $settings['minutes_label_font_size_tablet']['size'].$settings['minutes_label_font_size_tablet']['unit'] ?>;
				}
				.<?php echo $timerWrapper ?> .secondBox p {
					font-size: <?php echo $settings['seconds_label_font_size_tablet']['size'].$settings['seconds_label_font_size_tablet']['unit'] ?>;
				}
			}

			/* Medium devices (landscape tablets, 768px and up) */
			@media only screen and (min-width: 768px) {}

			/* Large devices (laptops/desktops, 992px and up) */
			@media only screen and (min-width: 992px) {}

			/* Extra large devices (large laptops and desktops, 1200px and up) */
			@media only screen and (min-width: 1200px) {}
		</style>
  		<?php
		echo '<div class="'.$timerWrapper.' timer">
			<div class="timerwrapper_">
				<div class="d-flex">
					<div class="hourBox flex-fill text-center">
						<div class="h hourBackgroundColor">
						 	<h1>00</h1>
						 	<p>'.$settings['hours_label'].'</p>
						 </div>
					</div>
					<div class="minuteBox flex-fill text-center">
						<div class="m minuteBackgroundColor">
						 	<h1>00</h1>
						 	<p>'.$settings['minutes_label'].'</p>
						 </div>
					</div>
					<div class="secondBox flex-fill text-center">
						<div class="s secondBackgroundColor">
						 	<h1>00</h1>
						 	<p>'.$settings['seconds_label'].'</p>
						 </div>
					</div>					
				</div>
			</div>
		</div>';

	}

	public function settings( $label ) {
		$settingString = trim(strtolower($label));

		// Box background color
		$this->add_control(
			$settingString.'_box_background_color',
			[
				'label' => __( $label.'Box Background Color', 'plugin-name' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '#fefefe',
			]
		);

		// Box padding
		$this->add_responsive_control(
			$settingString.'_box_padding',
			[
				'label' => __( $label.'Box Padding', 'plugin-name' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .widget-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		// Box Margin
		$this->add_responsive_control(
			$settingString.'_box_margin',
			[
				'label' => __( $label.'Box Margin', 'plugin-name' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .widget-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		// Hour Font Family
		$this->add_control(
			$settingString.'_font_family',
			[
				'label' => __( $label.'Font Family', 'plugin-domain' ),
				'type' => \Elementor\Controls_Manager::FONT,
				'default' => "'Open Sans', sans-serif",
				'selectors' => [
					'{{WRAPPER}} .title' => 'font-family: {{VALUE}}',
				]
			]
		);

		// Hour Label Text Color
		$this->add_control(
			$settingString.'_text_color',
			[
				'label' => __( $label.'Color', 'plugin-name' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '#fefefe',
			]
		);

		// Hour Font Size
		$this->add_responsive_control(
			$settingString.'_font_size',
			[
				'label' => __( $label.'Font Size', 'plugin-name' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices' => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' => 30,
					'unit' => 'px',
				],
				'tablet_default' => [
					'size' => 20,
					'unit' => 'px',
				],
				'mobile_default' => [
					'size' => 10,
					'unit' => 'px',
				],
				'selectors' => [
					'{{WRAPPER}} .widget-image' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

		// Box Margin
		$this->add_responsive_control(
			$settingString.'_margin',
			[
				'label' => __( $label.'Text Margin', 'plugin-name' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .widget-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		// Hour Label
		$this->add_control(
			$settingString.'_label',
			[
				'label' => __( $label.'Label', 'plugin-name' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'input_type' => 'text',
				'placeholder' => __( $settingString.'s Label', 'plugin-name' ),
				'default' => $label
			]
		);

		// Hour Label Font Family
		$this->add_control(
			$settingString.'_label_font_family',
			[
				'label' => __( $label.'Label Font Family', 'plugin-domain' ),
				'type' => \Elementor\Controls_Manager::FONT,
				'default' => "'Open Sans', sans-serif",
				'selectors' => [
					'{{WRAPPER}} .title' => 'font-family: {{VALUE}}',
				]
			]
		);

		// Hour Label Font Size
		$this->add_responsive_control(
			$settingString.'_label_font_size',
			[
				'label' => __( $label.'Label Font Size', 'plugin-name' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices' => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' => 30,
					'unit' => 'px',
				],
				'tablet_default' => [
					'size' => 20,
					'unit' => 'px',
				],
				'mobile_default' => [
					'size' => 10,
					'unit' => 'px',
				],
				'selectors' => [
					'{{WRAPPER}} .widget-image' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

		// Hour Label Text Color
		$this->add_control(
			$settingString.'_label_text_color',
			[
				'label' => __( $label.'Label Color', 'plugin-name' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '#fefefe',
			]
		);
	}

	public function getStyle( $str, $arr ) {		
		$ret = "";
		$ret .= $str.'-top:'.$arr['top'].$arr['unit'].';';
		$ret .= $str.'-right:'.$arr['right'].$arr['unit'].';';
		$ret .= $str.'-bottom:'.$arr['bottom'].$arr['unit'].';';
		$ret .= $str.'-left:'.$arr['left'].$arr['unit'].';';

		return $ret;
	}

}