<?php
/**
 * @wordpress-plugin
 * Plugin Name:       PlayIt Elementor Widgets
 * Plugin URI:        https://github.com/kunal1400
 * Description:       This is a short description of what the plugin does. It's displayed in the WordPress admin area.
 * Version:           1.0.0
 * Author:            Kunal Malviya
 * Author URI:        https://github.com/kunal1400
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       play-it-game
 * Domain Path:       /languages
 */

define( 'ELEMENTOR_AWESOMESAUCE', __FILE__ );

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

class Playit_Elementor_Timer_Widgets {

	protected static $instance = null;

	public static function get_instance() {
		if ( ! isset( static::$instance ) ) {
			static::$instance = new static;
		}

		return static::$instance;
	}

	protected function __construct() {
		require_once('timer.php');
		require_once('login_by_code.php');
		require_once('logout_button.php');
		add_action( 'elementor/widgets/widgets_registered', [ $this, 'register_timer_widget' ] );
	}

	public function register_timer_widget() {
		// Widget for Timer
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Elementor\Elementor_playit_Widget() );

		// Widget for Login
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Elementor\Elementor_playit_loginbycode_Widget() );

		// Widget for Logout
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Elementor\Elementor_playit_logout_Widget() );
	}

}

add_action( 'init', function () {
	Playit_Elementor_Timer_Widgets::get_instance();
});
