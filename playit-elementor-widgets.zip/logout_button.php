<?php
namespace Elementor;

class Elementor_playit_logout_Widget extends Widget_Base {
	public function __construct($data = [], $args = null) {
		parent::__construct($data, $args);
	}

	public function get_name() {
		return 'playit-logout-button';
	}

	public function get_title() {
		return __( 'Playit Logout Button', 'plugin-name' );
	}

	public function get_icon() {
		return 'eicon-lock-user';
	}

	public function get_categories() {
		return [ 'general' ];
	}

	protected function _register_controls() {
		/**
		* Hours Section
		**/
		$this->start_controls_section(
			'login_by_code',
			[
				'label' => __( 'Logout Button', 'plugin-name' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);		
		
		$this->settings();

		$this->end_controls_section();
		/*** END Content Section ***/		
	}

	protected function render() {
		$attributes = $this->get_settings_for_display();		
		
		if ( is_user_logged_in() ) {
			echo '<a href="'.wp_logout_url().'" class="btn btn-primary" style="background-color:'.$attributes['logout_button_background_color'].';border: 1px solid '.$attributes['logout_button_background_color'].';font-family:'.$attributes['logout_button_font_family'].';color:'.$attributes['logout_button_text_color'].'">'.$attributes['logout_button_label'].'</a>';
		}

	}

	public function settings() {
		$this->add_control(
			'logout_button_background_color',
			[
				'label' => __( 'Background Color', 'plugin-name' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '#23a455',
			]
		);

		$this->add_control(
			'logout_button_font_family',
			[
				'label' => __( 'Font Family', 'plugin-domain' ),
				'type' => \Elementor\Controls_Manager::FONT,
				'default' => "'Open Sans', sans-serif",
				'selectors' => [
					'{{WRAPPER}} .title' => 'font-family: {{VALUE}}',
				]
			]
		);

		$this->add_control(
			'logout_button_text_color',
			[
				'label' => __( 'Text Color', 'plugin-name' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '#fefefe',
			]
		);

		$this->add_control(
			'logout_button_label',
			[
				'label' => __( 'Button Label', 'plugin-name' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'input_type' => 'text',
				'placeholder' => __( 'Logout', 'plugin-name' ),
				'default' => 'Logout'
			]
		);

		// $this->add_control(
		// 	'logout_button_redirect_url',
		// 	[
		// 		'label' => __( 'Redirect URL', 'plugin-name' ),
		// 		'type' => \Elementor\Controls_Manager::URL,				
		// 		'default' => [
		// 			'url' => site_url(),
		// 		],
		// 		'options' => false,
		// 	]
		// );
	}
}