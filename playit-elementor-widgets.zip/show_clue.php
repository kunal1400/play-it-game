<?php
namespace Elementor;

class Elementor_playit_show_clue_Widget extends Widget_Base {
	public function __construct($data = [], $args = null) {
		parent::__construct($data, $args);
	}

	public function get_name() {
		return 'playit-show-clue';
	}

	public function get_title() {
		return __( 'Playit Show Clue Button', 'plugin-name' );
	}

	public function get_icon() {
		return 'eicon-animated-headline';
	}

	public function get_categories() {
		return [ 'general' ];
	}

	protected function _register_controls() {
		/**
		* Hours Section
		**/
		$this->start_controls_section(
			'show_clue_button',
			[
				'label' => __( 'Show Clue Button', 'plugin-name' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);		
		
		$this->settings();

		$this->end_controls_section();
		/*** END Content Section ***/		
	}

	protected function render() {
		$attributes = $this->get_settings_for_display();
		$cluewrapperLabelClass = "cluewrapperLabel".rand(10,10000);
		$clueTextClass = "clueTextClass".rand(10,10000);
		?>
		<style type="text/css">
			.<?php echo $cluewrapperLabelClass ?> {
				<?php if($attributes['show_clue_button_typography_font_size']['size'] && $attributes['show_clue_button_typography_font_size']['unit']): ?>	
					font-size: <?php echo $attributes['show_clue_button_typography_font_size']['size'].$attributes['show_clue_button_typography_font_size']['unit'] ?>;
				<?php endif; ?>
				<?php if ($attributes['show_clue_button_typography_font_weight']): ?>
					font-weight: <?php echo $attributes['show_clue_button_typography_font_weight'] ?>;
				<?php endif; ?>
				<?php if ($attributes['show_clue_button_typography_text_transform']): ?>
					text-transform: <?php echo $attributes['show_clue_button_typography_text_transform'] ?>;
				<?php endif; ?>
				<?php if ($attributes['show_clue_button_typography_text_decoration']): ?>
					text-decoration: <?php echo $attributes['show_clue_button_typography_text_decoration'].' !important' ?>;
				<?php endif; ?>
				<?php if ($attributes['show_clue_button_typography_font_family']): ?>
					font-family: <?php echo $attributes['show_clue_button_typography_font_family'] ?>;
				<?php endif; ?>
				<?php if ( $attributes['show_clue_button_typography_line_height']['size'] && $attributes['show_clue_button_typography_line_height']['unit'] ): ?>
					line-height: <?php echo $attributes['show_clue_button_typography_line_height']['size'].$attributes['show_clue_button_typography_font_size']['unit'] ?>;
				<?php endif; ?>
				<?php if ( $attributes['show_clue_button_typography_letter_spacing']['size'] && $attributes['show_clue_button_typography_letter_spacing']['unit'] ): ?>
					letter-spacing: <?php echo $attributes['show_clue_button_typography_letter_spacing']['size'].$attributes['show_clue_button_typography_letter_spacing']['unit'] ?>;
				<?php endif; ?>
			}

			.<?php echo $clueTextClass ?> {
				<?php if($attributes['clue_text_typography_font_size']['size'] && $attributes['clue_text_typography_font_size']['unit']): ?>	
					font-size: <?php echo $attributes['clue_text_typography_font_size']['size'].$attributes['clue_text_typography_font_size']['unit'] ?>;
				<?php endif; ?>
				<?php if ($attributes['clue_text_typography_font_weight']): ?>
					font-weight: <?php echo $attributes['clue_text_typography_font_weight'] ?>;
				<?php endif; ?>
				<?php if ($attributes['clue_text_typography_text_transform']): ?>
					text-transform: <?php echo $attributes['clue_text_typography_text_transform'] ?>;
				<?php endif; ?>
				<?php if ($attributes['clue_text_typography_text_decoration']): ?>
					text-decoration: <?php echo $attributes['clue_text_typography_text_decoration'].' !important' ?>;
				<?php endif; ?>
				<?php if ($attributes['clue_text_typography_font_family']): ?>
					font-family: <?php echo $attributes['clue_text_typography_font_family'] ?>;
				<?php endif; ?>
				<?php if ( $attributes['clue_text_typography_line_height']['size'] && $attributes['clue_text_typography_line_height']['unit'] ): ?>
					line-height: <?php echo $attributes['clue_text_typography_line_height']['size'].$attributes['clue_text_typography_font_size']['unit'] ?>;
				<?php endif; ?>
				<?php if ( $attributes['clue_text_typography_letter_spacing']['size'] && $attributes['clue_text_typography_letter_spacing']['unit'] ): ?>
					letter-spacing: <?php echo $attributes['clue_text_typography_letter_spacing']['size'].$attributes['clue_text_typography_letter_spacing']['unit'] ?>;
				<?php endif; ?>
			}

			/* Extra small devices (phones, 600px and down) */
			@media only screen and (max-width: 600px) {
				.<?php echo $cluewrapperLabelClass ?> {
					<?php if($attributes['show_clue_button_typography_font_size_mobile']['size'] && $attributes['show_clue_button_typography_font_size_mobile']['unit']): ?>	
					font-size: <?php echo $attributes['show_clue_button_typography_font_size_mobile']['size'].$attributes['show_clue_button_typography_font_size_mobile']['unit'] ?>;
					<?php endif; ?>
					<?php if ( $attributes['show_clue_button_typography_line_height_mobile']['size'] && $attributes['show_clue_button_typography_line_height_mobile']['unit'] ): ?>
						line-height: <?php echo $attributes['show_clue_button_typography_line_height_mobile']['size'].$attributes['show_clue_button_typography_font_size_mobile']['unit'] ?>;
					<?php endif; ?>
					<?php if ( $attributes['show_clue_button_typography_letter_spacing_mobile']['size'] && $attributes['show_clue_button_typography_letter_spacing_mobile']['unit'] ): ?>
						letter-spacing: <?php echo $attributes['show_clue_button_typography_letter_spacing_mobile']['size'].$attributes['show_clue_button_typography_letter_spacing_mobile']['unit'] ?>;
					<?php endif; ?>
				}
				.<?php echo $clueTextClass ?> {
					<?php if($attributes['clue_text_typography_font_size_mobile']['size'] && $attributes['clue_text_typography_font_size_mobile']['unit']): ?>	
					font-size: <?php echo $attributes['clue_text_typography_font_size_mobile']['size'].$attributes['clue_text_typography_font_size_mobile']['unit'] ?>;
					<?php endif; ?>
					<?php if ( $attributes['clue_text_typography_line_height_mobile']['size'] && $attributes['clue_text_typography_line_height_mobile']['unit'] ): ?>
						line-height: <?php echo $attributes['clue_text_typography_line_height_mobile']['size'].$attributes['clue_text_typography_font_size_mobile']['unit'] ?>;
					<?php endif; ?>
					<?php if ( $attributes['clue_text_typography_letter_spacing_mobile']['size'] && $attributes['clue_text_typography_letter_spacing_mobile']['unit'] ): ?>
						letter-spacing: <?php echo $attributes['clue_text_typography_letter_spacing_mobile']['size'].$attributes['clue_text_typography_letter_spacing_mobile']['unit'] ?>;
					<?php endif; ?>
				}
			}

			/* Small devices (portrait tablets and large phones, 600px and up) */
			@media only screen and (min-width: 600px) {
				.<?php echo $cluewrapperLabelClass ?> {
					<?php if($attributes['show_clue_button_typography_font_size_tablet']['size'] && $attributes['show_clue_button_typography_font_size_tablet']['unit']): ?>	
						font-size: <?php echo $attributes['show_clue_button_typography_font_size_tablet']['size'].$attributes['show_clue_button_typography_font_size_tablet']['unit'] ?>;
					<?php endif; ?>
					<?php if ( $attributes['show_clue_button_typography_line_height_tablet']['size'] && $attributes['show_clue_button_typography_line_height_tablet']['unit'] ): ?>
						line-height: <?php echo $attributes['show_clue_button_typography_line_height_tablet']['size'].$attributes['show_clue_button_typography_font_size_tablet']['unit'] ?>;
					<?php endif; ?>
					<?php if ( $attributes['show_clue_button_typography_letter_spacing_tablet']['size'] && $attributes['show_clue_button_typography_letter_spacing_tablet']['unit'] ): ?>
						letter-spacing: <?php echo $attributes['show_clue_button_typography_letter_spacing_tablet']['size'].$attributes['show_clue_button_typography_letter_spacing_tablet']['unit'] ?>;
					<?php endif; ?>
				}
				.<?php echo $clueTextClass ?> {
					<?php if($attributes['clue_text_typography_font_size_tablet']['size'] && $attributes['clue_text_typography_font_size_tablet']['unit']): ?>	
						font-size: <?php echo $attributes['clue_text_typography_font_size_tablet']['size'].$attributes['clue_text_typography_font_size_tablet']['unit'] ?>;
					<?php endif; ?>
					<?php if ( $attributes['clue_text_typography_line_height_tablet']['size'] && $attributes['clue_text_typography_line_height_tablet']['unit'] ): ?>
						line-height: <?php echo $attributes['clue_text_typography_line_height_tablet']['size'].$attributes['clue_text_typography_font_size_tablet']['unit'] ?>;
					<?php endif; ?>
					<?php if ( $attributes['clue_text_typography_letter_spacing_tablet']['size'] && $attributes['clue_text_typography_letter_spacing_tablet']['unit'] ): ?>
						letter-spacing: <?php echo $attributes['clue_text_typography_letter_spacing_tablet']['size'].$attributes['clue_text_typography_letter_spacing_tablet']['unit'] ?>;
					<?php endif; ?>
				}
			}
		</style>
		<?php

		$secondsToAdd = $attributes['show_clue_button_seconds_to_add'];
		if ($secondsToAdd && $secondsToAdd > 0) {
			$str = "<div style='background-color:".$attributes['show_clue_button_background_color'].";' class='cluewrapper'>";
				$str .= "<a class='".$cluewrapperLabelClass."' style='color:".$attributes['show_clue_button_text_color'].";' data-secondsToAdd='".$secondsToAdd."' href='javascript:void(0)' onclick='showclue(this)' class=''>".$attributes['show_clue_button_label']."</a>";
				$str .= "<div class='clue' style='display:none'>";
					if (!empty($attributes['show_clue_button_image_url']['url'])) {
						$str .= "<div class='imagewrapper'>
							<img src='".$attributes['show_clue_button_image_url']['url']."'/>
						</div>";
					}
					if (!empty($attributes['show_clue_button_text'])) {
						$str .= "<div class='textwrapper ".$clueTextClass."'>".$attributes['show_clue_button_text']."</div>";
					}
				$str .= "</div>";
			$str .= "</div>";
			echo $str;
		}

	}

	public function settings() {
		$this->add_control(
			'show_clue_button_seconds_to_add',
			[
				'label' => __( 'Seconds To Add', 'plugin-name' ),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'default' => 0,
			]
		);

		$this->add_control(
			'show_clue_button_background_color',
			[
				'label' => __( 'Background Color', 'plugin-name' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '#23a455',
			]
		);

		$this->add_control(
			'show_clue_button_label',
			[
				'label' => __( 'Button Label', 'plugin-name' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'input_type' => 'text',
				'placeholder' => __( 'Clue', 'plugin-name' ),
				'default' => 'Clue'
			]
		);

		$this->add_control(
			'show_clue_button_text_color',
			[
				'label' => __( 'Text Color', 'plugin-name' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '#000',
			]
		);		

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'show_clue_button_typography',
				'label' => __( 'Typography', 'plugin-domain' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .text',
			]
		);

		$this->add_control(
			'show_clue_button_image_url',
			[
				'label' => __( 'Clue Image', 'plugin-name' ),
				'type' => \Elementor\Controls_Manager::MEDIA
			]
		);

		$this->add_control(
			'show_clue_button_text',
			[
				'label' => __( 'Clue Text', 'plugin-name' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'input_type' => 'text',
				'default' => ''
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'clue_text_typography',
				'label' => __( 'Typography', 'plugin-domain' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .text',
			]
		);
	}
}