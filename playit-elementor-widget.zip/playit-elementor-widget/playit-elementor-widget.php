<?php
/**
 * @wordpress-plugin
 * Plugin Name:       PlayIt Elementor Widget
 * Plugin URI:        https://github.com/kunal1400
 * Description:       This is a short description of what the plugin does. It's displayed in the WordPress admin area.
 * Version:           1.0.0
 * Author:            Kunal Malviya
 * Author URI:        https://github.com/kunal1400
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       play-it-game
 * Domain Path:       /languages
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

class Playit_Elementor_Widgets {

	protected static $instance = null;

	public static function get_instance() {
		if ( ! isset( static::$instance ) ) {
			static::$instance = new static;
		}

		return static::$instance;
	}

	protected function __construct() {
		require_once('timer.php');
		add_action( 'elementor/widgets/widgets_registered', [ $this, 'register_widgets' ] );
	}

	public function register_widgets() {
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Elementor\Elementor_playit_Widget() );
	}

}

add_action( 'init', 'my_elementor_init' );
function my_elementor_init() {
	Playit_Elementor_Widgets::get_instance();
}