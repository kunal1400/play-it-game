<?php
namespace Elementor;

class Elementor_playit_Widget extends Widget_Base {
	public function __construct($data = [], $args = null) {
		parent::__construct($data, $args);
		wp_register_script( 'playit-scripts', 'js/script.js', [ 'elementor-frontend' ], '1.0.0', true );
		wp_register_style( 'playit-styles', 'css/style.css');
	}

	public function get_script_depends() {
		return [ 'playit-scripts' ];
	}

	public function get_style_depends() {
		return [ 'playit-styles' ];
	}

	public function get_name() {
		return 'Playit';
	}

	public function get_title() {
		return __( 'Playit Timer', 'plugin-name' );
	}

	public function get_icon() {
		return 'fa fa-code';
	}

	public function get_categories() {
		return [ 'general' ];
	}

	protected function _register_controls() {
		/**
		* Hours Section
		**/
		$this->start_controls_section(
			'hours_section',
			[
				'label' => __( 'Hours', 'plugin-name' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);		
		
		$this->settings('Hours ');

		$this->end_controls_section();
		/*** END Content Section ***/

		/**
		* Hours Section
		**/
		$this->start_controls_section(
			'minutes_section',
			[
				'label' => __( 'Minutes', 'plugin-name' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);		
		
		$this->settings('Minutes ');

		$this->end_controls_section();
		/*** END Content Section ***/

		/**
		* Hours Section
		**/
		$this->start_controls_section(
			'seconds_section',
			[
				'label' => __( 'Seconds', 'plugin-name' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);		
		
		$this->settings('Seconds ');

		$this->end_controls_section();
		/*** END Content Section ***/		
	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		$hours_box_padding = $this->getStyle( 'padding', $settings['hours_box_padding'] );
		$hours_box_margin = $this->getStyle( 'margin', $settings['hours_box_margin'] );		
		$hours_margin = $this->getStyle( 'margin', $settings['hours_margin'] );	

		$minutes_box_padding = $this->getStyle( 'padding', $settings['minutes_box_padding'] );
		$minutes_box_margin = $this->getStyle( 'margin', $settings['minutes_box_margin'] );		
		$minutes_margin = $this->getStyle( 'margin', $settings['minutes_margin'] );	

		$seconds_box_padding = $this->getStyle( 'padding', $settings['seconds_box_padding'] );
		$seconds_box_margin = $this->getStyle( 'margin', $settings['seconds_box_margin'] );		
		$seconds_margin = $this->getStyle( 'margin', $settings['seconds_margin'] );		

		echo '<div class="timer">
			<div class="timerwrapper_">
				<div class="d-flex">
					<div style="'.$hours_box_margin.'" class="flex-fill text-center">
						<div style="'.$hours_box_padding.';background-color:'.$settings['box_background_color'].';" class="h">
						 	<h1 style="font-family:'.$settings['hours_font_family'].';color:'.$settings['hours_text_color'].';'.$hours_margin.'">00</h1>
						 	<p style="font-family:'.$settings['hours_label_font_family'].';color:'.$settings['hours_label_text_color'].'">'.$settings['hours_label'].'</p>
						 </div>
					</div>
					<div style="'.$minutes_box_margin.'" class="flex-fill text-center">
						<div style="'.$minutes_box_padding.';background-color:'.$settings['box_background_color'].';" class="m">
						 	<h1 style="font-family:'.$settings['minutes_font_family'].';color:'.$settings['minutes_text_color'].';'.$minutes_margin.'">00</h1>
						 	<p style="font-family:'.$settings['minutes_label_font_family'].';color:'.$settings['minutes_label_text_color'].'">'.$settings['minutes_label'].'</p>
						 </div>
					</div>
					<div style="'.$seconds_box_margin.'" class="flex-fill text-center">
						<div style="'.$seconds_box_padding.';background-color:'.$settings['box_background_color'].';" class="s">
						 	<h1 style="font-family:'.$settings['seconds_font_family'].';color:'.$settings['seconds_text_color'].';'.$seconds_margin.'">00</h1>
						 	<p style="font-family:'.$settings['seconds_label_font_family'].';color:'.$settings['seconds_label_text_color'].'">'.$settings['seconds_label'].'</p>
						 </div>
					</div>					
				</div>
			</div>
		</div>';

	}

	// public function hours_settings() {
	// 	// Box background color
	// 	$this->add_control(
	// 		'box_background_color',
	// 		[
	// 			'label' => __( 'Box Background Color', 'plugin-name' ),
	// 			'type' => \Elementor\Controls_Manager::COLOR,
	// 			'default' => '#fefefe',
	// 		]
	// 	);

	// 	// Box padding
	// 	$this->add_responsive_control(
	// 		'box_padding',
	// 		[
	// 			'label' => __( 'Box Padding', 'plugin-name' ),
	// 			'type' => \Elementor\Controls_Manager::DIMENSIONS,
	// 			'size_units' => [ 'px', 'em', '%' ],
	// 			'selectors' => [
	// 				'{{WRAPPER}} .widget-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
	// 			],
	// 		]
	// 	);

	// 	// Box Margin
	// 	$this->add_responsive_control(
	// 		'box_margin',
	// 		[
	// 			'label' => __( 'Box Margin', 'plugin-name' ),
	// 			'type' => \Elementor\Controls_Manager::DIMENSIONS,
	// 			'size_units' => [ 'px', 'em', '%' ],
	// 			'selectors' => [
	// 				'{{WRAPPER}} .widget-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
	// 			],
	// 		]
	// 	);

	// 	// Hour Font Family
	// 	$this->add_control(
	// 		'hours_font_family',
	// 		[
	// 			'label' => __( 'Hour Font Family', 'plugin-domain' ),
	// 			'type' => \Elementor\Controls_Manager::FONT,
	// 			'default' => "'Open Sans', sans-serif",
	// 			'selectors' => [
	// 				'{{WRAPPER}} .title' => 'font-family: {{VALUE}}',
	// 			]
	// 		]
	// 	);

	// 	// Hour Label Text Color
	// 	$this->add_control(
	// 		'hours_text_color',
	// 		[
	// 			'label' => __( 'Hour Color', 'plugin-name' ),
	// 			'type' => \Elementor\Controls_Manager::COLOR,
	// 			'default' => '#fefefe',
	// 		]
	// 	);

	// 	// Hour Font Size
	// 	$this->add_responsive_control(
	// 		'hours_font_size',
	// 		[
	// 			'label' => __( 'Hour Font Size', 'plugin-name' ),
	// 			'type' => \Elementor\Controls_Manager::SLIDER,
	// 			'range' => [
	// 				'px' => [
	// 					'min' => 0,
	// 					'max' => 100,
	// 				],
	// 			],
	// 			'devices' => [ 'desktop', 'tablet', 'mobile' ],
	// 			'desktop_default' => [
	// 				'size' => 30,
	// 				'unit' => 'px',
	// 			],
	// 			'tablet_default' => [
	// 				'size' => 20,
	// 				'unit' => 'px',
	// 			],
	// 			'mobile_default' => [
	// 				'size' => 10,
	// 				'unit' => 'px',
	// 			],
	// 			'selectors' => [
	// 				'{{WRAPPER}} .widget-image' => 'margin-bottom: {{SIZE}}{{UNIT}};',
	// 			],
	// 		]
	// 	);

	// 	// Hour Label
	// 	$this->add_control(
	// 		'hours_label',
	// 		[
	// 			'label' => __( 'Hours Label', 'plugin-name' ),
	// 			'type' => \Elementor\Controls_Manager::TEXT,
	// 			'input_type' => 'text',
	// 			'placeholder' => __( 'Hours Label', 'plugin-name' ),
	// 		]
	// 	);

	// 	// Hour Label Font Family
	// 	$this->add_control(
	// 		'hours_label_font_family',
	// 		[
	// 			'label' => __( 'Hour Label Font Family', 'plugin-domain' ),
	// 			'type' => \Elementor\Controls_Manager::FONT,
	// 			'default' => "'Open Sans', sans-serif",
	// 			'selectors' => [
	// 				'{{WRAPPER}} .title' => 'font-family: {{VALUE}}',
	// 			]
	// 		]
	// 	);

	// 	// Hour Label Font Size
	// 	$this->add_responsive_control(
	// 		'hours_label_font_size',
	// 		[
	// 			'label' => __( 'Hour Label Font Size', 'plugin-name' ),
	// 			'type' => \Elementor\Controls_Manager::SLIDER,
	// 			'range' => [
	// 				'px' => [
	// 					'min' => 0,
	// 					'max' => 100,
	// 				],
	// 			],
	// 			'devices' => [ 'desktop', 'tablet', 'mobile' ],
	// 			'desktop_default' => [
	// 				'size' => 30,
	// 				'unit' => 'px',
	// 			],
	// 			'tablet_default' => [
	// 				'size' => 20,
	// 				'unit' => 'px',
	// 			],
	// 			'mobile_default' => [
	// 				'size' => 10,
	// 				'unit' => 'px',
	// 			],
	// 			'selectors' => [
	// 				'{{WRAPPER}} .widget-image' => 'margin-bottom: {{SIZE}}{{UNIT}};',
	// 			],
	// 		]
	// 	);

	// 	// Hour Label Text Color
	// 	$this->add_control(
	// 		'hours_label_text_color',
	// 		[
	// 			'label' => __( 'Hour Label Color', 'plugin-name' ),
	// 			'type' => \Elementor\Controls_Manager::COLOR,
	// 			'default' => '#fefefe',
	// 		]
	// 	);
	// }

	public function settings( $label ) {
		$settingString = trim(strtolower($label));

		// Box background color
		$this->add_control(
			$settingString.'_box_background_color',
			[
				'label' => __( $label.'Box Background Color', 'plugin-name' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '#fefefe',
			]
		);

		// Box padding
		$this->add_responsive_control(
			$settingString.'_box_padding',
			[
				'label' => __( $label.'Box Padding', 'plugin-name' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .widget-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		// Box Margin
		$this->add_responsive_control(
			$settingString.'_box_margin',
			[
				'label' => __( $label.'Box Margin', 'plugin-name' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .widget-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		// Hour Font Family
		$this->add_control(
			$settingString.'_font_family',
			[
				'label' => __( $label.'Font Family', 'plugin-domain' ),
				'type' => \Elementor\Controls_Manager::FONT,
				'default' => "'Open Sans', sans-serif",
				'selectors' => [
					'{{WRAPPER}} .title' => 'font-family: {{VALUE}}',
				]
			]
		);

		// Hour Label Text Color
		$this->add_control(
			$settingString.'_text_color',
			[
				'label' => __( $label.'Color', 'plugin-name' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '#fefefe',
			]
		);

		// Hour Font Size
		$this->add_responsive_control(
			$settingString.'_font_size',
			[
				'label' => __( $label.'Font Size', 'plugin-name' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices' => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' => 30,
					'unit' => 'px',
				],
				'tablet_default' => [
					'size' => 20,
					'unit' => 'px',
				],
				'mobile_default' => [
					'size' => 10,
					'unit' => 'px',
				],
				'selectors' => [
					'{{WRAPPER}} .widget-image' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

		// Box Margin
		$this->add_responsive_control(
			$settingString.'_margin',
			[
				'label' => __( $label.'Text Margin', 'plugin-name' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .widget-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		// Hour Label
		$this->add_control(
			$settingString.'_label',
			[
				'label' => __( $label.'Label', 'plugin-name' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'input_type' => 'text',
				'placeholder' => __( $settingString.'s Label', 'plugin-name' ),
				'default' => $label
			]
		);

		// Hour Label Font Family
		$this->add_control(
			$settingString.'_label_font_family',
			[
				'label' => __( $label.'Label Font Family', 'plugin-domain' ),
				'type' => \Elementor\Controls_Manager::FONT,
				'default' => "'Open Sans', sans-serif",
				'selectors' => [
					'{{WRAPPER}} .title' => 'font-family: {{VALUE}}',
				]
			]
		);

		// Hour Label Font Size
		$this->add_responsive_control(
			$settingString.'_label_font_size',
			[
				'label' => __( $label.'Label Font Size', 'plugin-name' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices' => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' => 30,
					'unit' => 'px',
				],
				'tablet_default' => [
					'size' => 20,
					'unit' => 'px',
				],
				'mobile_default' => [
					'size' => 10,
					'unit' => 'px',
				],
				'selectors' => [
					'{{WRAPPER}} .widget-image' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

		// Hour Label Text Color
		$this->add_control(
			$settingString.'_label_text_color',
			[
				'label' => __( $label.'Label Color', 'plugin-name' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '#fefefe',
			]
		);
	}

	public function getStyle( $str, $arr ) {		
		$ret = "";
		$ret .= $str.'-top:'.$arr['top'].$arr['unit'].';';
		$ret .= $str.'-right:'.$arr['right'].$arr['unit'].';';
		$ret .= $str.'-bottom:'.$arr['bottom'].$arr['unit'].';';
		$ret .= $str.'-left:'.$arr['left'].$arr['unit'].';';

		return $ret;
	}

}